<?php

require_once(dirname(__FILE__) . '/gantry-dropdown/theme.php');
RokNavMenu::registerTheme(dirname(__FILE__).'/gantry-dropdown','gantry-dropdown', 'gantry-dropdown', 'GantryDropdownTheme');

require_once(dirname(__FILE__) . '/gantry-splitmenu/theme.php');
RokNavMenu::registerTheme(dirname(__FILE__).'/gantry-splitmenu','gantry-splitmenu', 'gantry-splitmenu', 'GantrySplitmenuTheme');
